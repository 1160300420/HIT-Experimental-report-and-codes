#include "Floyd.h"

void Floyd::buildG(int G[][NUM]){
	int p, q, weight;
	int m;
	cin >> m;
	for (int i = 0; i < NUM; i++){       //initial G
		for (int j = 0; j < NUM; j++){
			if (i == j){
				G[i][j] = 0;
			}
			else{
				G[i][j] = INF;
			}

		}
	}
	for (int i = 0; i < m; i++){
		cin >> p >> q >> weight;
		G[p][q] = weight;
	}
}

void Floyd::floydCal(int G[][NUM], int A[][NUM], int P[][NUM]){
	for (int i = 0; i < NUM; i++){
		for (int j = 0; j < NUM; j++){
			A[i][j] = G[i][j];
			P[i][j] = -1;
		}
	}
	for (int k = 0; k < NUM; k++){
		for (int i = 0; i < NUM; i++){
			for (int j = 0; j < NUM; j++){
				if (A[i][k] + A[k][j] < A[i][j]){
					A[i][j] = A[i][k] + A[k][j];
					P[i][j] = k;
				}
			}
		}
	}
}

void Floyd::getFloyd(){
	int A[NUM][NUM], P[NUM][NUM];
	buildG(G);

	floydCal(G, A, P);

	for (int i = 0; i < NUM; i++){
		for (int j = 0; j < NUM; j++){
			cout << A[i][j] << ' ';
		}
		cout << endl;
	}
}