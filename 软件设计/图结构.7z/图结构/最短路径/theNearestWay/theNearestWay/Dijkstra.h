#include <iostream>
#define NUM 5
#define INF 1000

using namespace std;

class Dijkstra{
private:
	int G[NUM][NUM];
	int m;
public:
	void buildG(int G[][NUM]);

	int minCost(int *D, bool *S);

	void dijkstraCal(int G[][NUM], int *D, int *P, bool *S);

	void sourceToNode(int *P);

	void getDijkstra();

};