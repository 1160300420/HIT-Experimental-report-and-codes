#include "Dijkstra.h"

void Dijkstra::buildG(int G[][NUM]){
	int p, q, weight;
	int m;
	cin >> m;
	for (int i = 0; i < NUM; i++){       //initial G
		for (int j = 0; j < NUM; j++){
			if (i == j){
				G[i][j] = 0;
			}
			else{
				G[i][j] = INF;
			}

		}
	}
	for (int i = 0; i < m; i++){
		cin >> p >> q >> weight;
		G[p][q] = weight;
	}
}

int Dijkstra::minCost(int *D, bool *S){
	int w = 1;
	int tmp = INF;
	for (int i = 1; i < NUM; i++){
		if (!S[i] && D[i] < tmp){
			tmp = D[i];
			w = i;
		}
	}
	return w;
}

void Dijkstra::dijkstraCal(int G[][NUM], int *D, int *P, bool *S){
	int w;
	for (int i = 1; i < NUM; i++){
		D[i] = G[0][i];
		S[i] = false;
		P[i] = 0;
	}
	S[1] = true;
	for (int i = 0; i < NUM - 1; i++){
		w = minCost(D, S);
		S[w] = true;
		for (int v = 1; v < NUM; v++){
			if (!S[v]){
				if ((D[w] + G[w][v]) < D[v]){
					D[v] = D[w] + G[w][v];
					P[v] = w;
				}
			}
		}
	}
}

void Dijkstra::sourceToNode(int *P){
	int node;
	cin >> node;
	while (node != -1){
		while (node){
			cout << node;
			node = P[node];
		}
		cout << node << endl;
		cin >> node;
	}
}

void Dijkstra::getDijkstra(){
	int D[NUM];  //the shortest distance
	int P[NUM];  //the last node of the present node
	bool S[NUM];   //figure the node visited or not

	buildG(G);

	dijkstraCal(G, D, P, S);

	sourceToNode(P);
}