#include <iostream>
#define NUM 4
#define INF 1000

using namespace std;

class Floyd{
private:
	int G[NUM][NUM];
	int m;
public:
	void buildG(int G[][NUM]);

	void floydCal(int G[][NUM], int A[][NUM], int P[][NUM]);

	void getFloyd();

};