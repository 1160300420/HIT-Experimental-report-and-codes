#include <iostream>
#define INF 1e+3
#define NUM 6

struct edge{
	char bgn;
	char end;
	int weight;
};

using namespace std;

class Kraskal{
private:
	int *father;
	int m;
public:

	void kraskalCal(edge *edges);

	int Find(int *father,int v);

	void sortEdges(edge *edges);

	void getKruskal();
};