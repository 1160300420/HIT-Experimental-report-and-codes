#include "Kruskal.h"

void Kraskal::kraskalCal(edge *edges){
	int bnf, edf;
	father = new int[m];
	memset(father, 0, m*sizeof(int));
	for (int i = 0; i < m; i++){
		father[i] = 0;
	}
	for (int i = 0; i < m;i++)
	{
		bnf = Find(father, edges[i].bgn-'A');
		edf = Find(father, edges[i].end-'A');
		if (bnf != edf){
			father[bnf] = edf;
			cout << edges[i].bgn << edges[i].end << ' ' << edges[i].weight << endl;
		}
	}
}

int Kraskal::Find(int *father, int v){
	int f = v;
	while (father[f] > 0){
		f = father[f];
	}
	return f;
}

void swap(edge &p, edge &q){
	edge tmp;
	tmp = p;
	p = q;
	q = tmp;
}

void Kraskal::sortEdges(edge *edges){
	for (int i = 0; i < m - 1; i++){
		for (int j = m - 1; j >= i + 1; j--){
			if (edges[j].weight < edges[j - 1].weight){
				swap(edges[j], edges[j - 1]);
			}
		}
	}
}

void Kraskal::getKruskal(){
	cin >> m;
	edge *edges=new edge[m];
	for (int i = 0; i < m; i++){
		cin >> edges[i].bgn >> edges[i].end >> edges[i].weight;
	}
	sortEdges(edges);
	kraskalCal(edges);
	for (int i = 0; i < m; i++){
		cout <<char('A'+father[i])<<' ';
	}
	/*
	for (int i = 0; i < m; i++){
		cout << edges[i].weight << ' ';
	}
	*/
}