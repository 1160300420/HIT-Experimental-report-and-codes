#include "Prim.h"

void Prim::buildG(int G[][20], int &n, int &m){
	Node node;
	cin >> n >> m;
	for (int i = 0; i < n; i++){
		for (int j = 0; j < n; j++){
			if (i != j)
				G[i][j] = INF;       //others to be initialed as INF
			else
				G[i][j] = 0;
		}
	}

	for (int i = 0; i < m; i++){
		cin >> node.u >> node.v >> node.weight;
		G[node.u - 'A'][node.v - 'A'] = G[node.v - 'A'][node.u - 'A'] = node.weight;
	}
}

void Prim::primCal(int G[][20], int n, int lowcost[], char closest[]){
	int min, k;            //k is to record the position of the min
	int flag[20] = { 1, 0 };          //A does not need to be calculate
	for (int i = 0; i < n; i++){
		lowcost[i] = G[0][i];
		closest[i] = 'A';          //intial
	}
	for (int i = 1; i < n; i++){
		if (flag[i]) continue;          //the flag, to flag the node which is visited
		min = lowcost[i];
		for (int j = 1; j < n; j++){              //to find the position and the amount of the min
			if (lowcost[j] < min && !flag[j]){
				min = lowcost[j];
				k = j;
				flag[k] = 1;            //has been visited
			}
		}

		for (int j = 1; j < n; j++){
			if (G[k][j] < lowcost[j] && !flag[j]){
				lowcost[j] = G[k][j];      //compare the lowcost
				closest[j] = k + 'A';          //record the closest node
			}
		}
	}
}

void Prim::getPrim(){
	int G[20][20];
	int lowcost[20];
	char closest[20];
	int n, m;
	buildG(G, n, m);        //build the gragh
	primCal(G, n, lowcost, closest);   //calculate the MST(Minimal Spanning Tree)

	for (int i = 1; i < n; i++){
		cout << char(i + 'A') << closest[i] << ": " << lowcost[i] << endl;
	}
}