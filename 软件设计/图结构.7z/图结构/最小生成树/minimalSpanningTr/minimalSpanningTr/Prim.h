//undirected gragh with weight
#include <iostream>
#define INF 1e+3

struct Node{
	char u;
	char v;
	int weight;
};

using namespace std;

class Prim{
public:
	void buildG(int G[][20], int &n, int &m);

	void primCal(int G[][20], int n, int lowcost[], char closest[]);

	void getPrim();
};