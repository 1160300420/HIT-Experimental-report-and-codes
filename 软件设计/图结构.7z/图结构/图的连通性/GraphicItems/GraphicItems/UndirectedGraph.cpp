#include "UndirectedGraph.h"

void UDG::matrixCreateGraph(){
	int e;
	char c1, c2;

	GM = new MatrixGraph;

	for (int i = 0; i < NUM; i++){
		cin >> GM->vertlist[i];
	}
	cin >> e;
	for (int i = 0; i < NUM; i++){
		for (int j = 0; j < NUM; j++){
			GM->edge[i][j] = 0;
		}
	}
	for (int k = 0; k < e; k++){
		cin >> c1 >> c2;
		GM->edge[c1 - 'A'][c2 - 'A'] = 1;
		GM->edge[c2 - 'A'][c1 - 'A'] = 1;
	}
}

void UDG::tarjan1(int u, int *DFN, int *LOW,MatrixGraph *GM,int *v){
	v[u] = 1;
	DFN[u] = LOW[u] = ++index;
	for (int i = 0; i < NUM; i++){
		if (GM->edge[u][i]){
			if (!DFN[i]){
				tarjan1(i, DFN, LOW, GM,v);
				LOW[u] = min(LOW[u], LOW[i]);
				if (DFN[u] <= LOW[i]){
					v[u]++;
				}
			}
			else {
				LOW[u] = min(LOW[u], DFN[i]);
			}
		}
	}
	if ((u == 0 && v[u]>2) || (u>0 && v[u]>1)) 
		v[u] = 2; 
	else 
		v[u] = 1;
}



void UDG::dblConnected1(){  //node
	int DFN[NUM] = { 0 }, LOW[NUM] = { 0 }, visited[NUM] = { 0 }, v[NUM] = {0};
	for (int i = 0; i < NUM; i++){
		if (!DFN[i]){
			tarjan1(i, DFN, LOW,GM,v);
		}
	}
	cout << "���Ϊ��";
	for (int i = 0; i < NUM; i++){
		if (v[i] == 2)
			cout << char(i+'A') << ' ';
	}	
}

void UDG::tarjan2(int u, int *DFN, int *LOW, MatrixGraph *GM, int *visited,int *p){
	visited[u] = 1;
	
	DFN[u] = LOW[u] = ++index2;
	for (int i = 0; i < NUM; i++){
		if (GM->edge[u][i]){
			if (!visited[i]){
				p[i] = u;
				tarjan2(i, DFN, LOW, GM, visited,p);
				LOW[u] = min(LOW[u], LOW[i]);
			}
			else if (p[u] != i)
				LOW[u] = min(LOW[u], DFN[i]);
		}
	}

	if (p[u]>0 && LOW[u] == DFN[u])
		cout << char(u+'A')<<char(p[u]+'A')<<' ';
}

void UDG::dblConnected2(){  //edge
	int DFN[NUM] = { 0 }, LOW[NUM] = { 0 }, visited[NUM] = { 0 }, p[NUM];
	memset(p, -1, NUM*sizeof(int));
	cout << "���Ϊ��";
	for (int i = 0; i < NUM; i++){
		if (!DFN[i]){
			tarjan2(2, DFN, LOW, GM, visited,p);
		}
	}
	
}