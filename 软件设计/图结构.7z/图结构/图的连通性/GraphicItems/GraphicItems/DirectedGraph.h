#include <iostream>
#include <queue>
#include <stack>
#define NUM 5

using namespace std;

typedef struct node{
	int adjvex;  //�ڽӵ�
	struct node *next;
}EdgeNode;     //�߱�

typedef struct{
	char vertex;
	EdgeNode *firstedge;
}VertexNode;    //�����

typedef struct{
	VertexNode vexlist[100];
	int n;  //num of vertex
	int e;  //num of edge
}AdjGraph;

struct MatrixGraph{
	char vertlist[NUM];
	int edge[NUM][NUM];
};

class DG{
private:
	AdjGraph *GA;
	MatrixGraph *GM;
	int index = 0;
public:
	void adjCreateGraph();

	void matrixCreateGraph();

	void tarjan(int u, int *DFN, int *LOW, stack<int> &st, MatrixGraph *GM);

	void stronglyConnected1();  //Tarjan

	void stronglyConnected2();   //Kosaraju
};