// GraphicItems.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include "DirectedGraph.h"
//#include "UndirectedGraph.h"

int main()
{
	
	DG dg;
	dg.matrixCreateGraph();

	//dg.stronglyConnected1();

	dg.stronglyConnected2();
	

	/*
	UDG udg;
	udg.matrixCreateGraph();

	udg.dblConnected1();

	udg.dblConnected2();
	*/
	return 0;
}

