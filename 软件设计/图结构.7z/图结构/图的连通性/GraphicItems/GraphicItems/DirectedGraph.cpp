#include "DirectedGraph.h"

int min(int a, int b) {
	return (a < b) ? a : b;
}

bool inStack(stack<int> st,int u){
	int v;
	while (!st.empty()){
		v = st.top();
		st.pop();
		if (v == u){
			return true;
		}
	}
	return false;
}

void DG::adjCreateGraph(){
		char tail, head;

		cin >> GA->n >> GA->e;

		for (int i = 0; i < GA->n; i++){
			cin >> GA->vexlist[i].vertex;
			GA->vexlist[i].firstedge = NULL;
		}

		for (int i = 0; i < GA->e; i++){
			cin >> tail >> head;
			getchar();
			EdgeNode *p = new EdgeNode;
			p->adjvex = head - 'A';
			p->next = GA->vexlist[tail - 'A'].firstedge;
			GA->vexlist[tail - 'A'].firstedge = p;
		}
}

void DG::matrixCreateGraph(){
	int e;
	char c1, c2;

	GM = new MatrixGraph;

	for (int i = 0; i < NUM; i++){
		cin >> GM->vertlist[i];
	}
	cin >> e;
	for (int i = 0; i < NUM; i++){
		for (int j = 0; j < NUM; j++){
			GM->edge[i][j] = 0;
		}
	}
	for (int k = 0; k < e; k++){
		cin >> c1 >> c2;
		GM->edge[c1 - 'A'][c2 - 'A'] = 1;
	}
}

void DG::tarjan(int u, int *DFN, int *LOW,stack<int> &st, MatrixGraph *GM){
	int v;
	DFN[u] = LOW[u] = ++index;
	st.push(u);
	for (int i = 0; i < NUM; i++){
		if (GM->edge[u][i]){
			if (!DFN[i]){
				tarjan(i, DFN, LOW,st, GM);
				LOW[u] = min(LOW[u], LOW[i]);
			}
			else if (inStack(st, i)){
				LOW[u] = min(LOW[u], DFN[i]);
			}			
		}
	}

	if (DFN[u] == LOW[u]){
		do{
			v = st.top();
			st.pop();
			cout << char('A' + v) << ' ';
		} while (u != v);
		cout << endl;
	}
}

void DG::stronglyConnected1(){   //Tarjan
	int DFN[NUM] = { 0 }, LOW[NUM] = { 0 };
	stack<int> st;
	for (int i = 0; i < NUM; i++){
		if (!DFN[i]){
			tarjan(i, DFN, LOW,  st, GM);
		}
	}
}

void k_dfs1(int u,int *visited,MatrixGraph *GM,stack<int> &st){
	visited[u] = 1;
	for (int i = 0; i < NUM; i++){
		if (GM->edge[u][i]){
			if (!visited[i]){
				k_dfs1(i, visited, GM,st);
			}
		}
	}
	st.push(u);    //����ʱ������
}

void k_dfs2(int u,int *visited,int nedge[NUM][NUM]){
	visited[u] = 1;
	for (int i = 0; i < NUM; i++){
		if (nedge[u][i] && 0==visited[i]){
			k_dfs2(i, visited, nedge);
		}
	}
}

void kosaraju(int *visited,MatrixGraph *GM,int nedge[NUM][NUM] ,stack<int> &st){
	int v;
	memset(visited, 0, sizeof(int)*NUM);
	for (int i = 0; i < NUM; i++){
		if (!visited[i]){
			k_dfs1(i, visited, GM, st);
		}
	}
	int t = 0;
	memset(visited, 0, sizeof(int)*NUM);

	while (!st.empty())
	{
		v = st.top();
		st.pop();
		
		if (0==visited[v]){

			t++;
			k_dfs2(v, visited, nedge);
			for (int i = 0; i < NUM; i++){
				if (1==visited[i]){
					cout << char(i + 'A') << ' ';
					visited[i] = -1;
				}
			}
			cout << endl;
		}
	}
	cout << t << endl;
}

void DG::stronglyConnected2(){    //kosaraju
	int nedge[NUM][NUM], visited[NUM] = {0};
	stack<int> st;
	memset(nedge, 0, sizeof(nedge));
	for (int i = 0; i < NUM; i++){
		for (int j = 0; j < NUM; j++){
			if (GM->edge[i][j]){
				nedge[j][i] = 1;
			}
		}
	}
	kosaraju(visited, GM, nedge, st);
	
}
