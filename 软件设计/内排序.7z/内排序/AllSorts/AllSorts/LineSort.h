#include <iostream>
#include <queue>

#define NUM 10
#define FIGURE 3

using namespace std;

class LSort{
private:
	int A[NUM];
	int B[NUM];
	queue<int> q;
public:
	void inputArr();

	void printArr();

	void printQueue();

	void countSort();

	void cardinalNumSort();
};

void LSort::inputArr(){
	for (int i = 0; i < NUM; i++){
		cin >> A[i];
		q.push(A[i]);
	}
}

void LSort::printArr(){
	for (int i = 0; i < NUM; i++){
		cout << B[i] << ' ';
	}
}

void LSort::printQueue(){
	int tmp;
	while (!q.empty()){
		tmp = q.front();
		q.pop();
		cout << tmp << ' ';
	}
}

void LSort::countSort(){
	int cnt[NUM] = {0};
	int n = 0;
	for (int i = 0; i < NUM; i++){
		cnt[A[i]]++;
	}

	for (int i = 0; i < NUM; i++){
		while (cnt[i]--){
			B[n++] = i;
		}
	}
}

void makeNull(queue<int> q){
	while (!q.empty()){
		q.pop();
	}
}

int radixNum(int data, int pass){
	int power = 1;
	for (int i = 1; i <= pass - 1; i++){
		power *= 10;
	}
	return ((data % (power * 10)) / power);
}

void LSort::cardinalNumSort(){
	queue<int> Q[10];
	int r,data;
	for (int pass = 1; pass <= FIGURE; pass++){
		for (int i = 0; i < 10; i++){
			makeNull(Q[i]);
		}
		while(!q.empty()){
			data = q.front();
			q.pop();
			r = radixNum(data, pass);
			Q[r].push(data);
		}
		for (int k = 0; k < 10; k++){
			while (!Q[k].empty()){
				data = Q[k].front();
				Q[k].pop();
				q.push(data);
			}
		}
	}
}