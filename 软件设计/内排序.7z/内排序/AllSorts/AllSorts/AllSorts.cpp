// AllSorts.cpp : �������̨Ӧ�ó������ڵ㡣
//

//#include "BasicSorts.h"
#include "LineSort.h"

#include <ctime>
#include <stdlib.h>

int main()
{
	/*
	BSorts<int> bs;
	clock_t begin, end;

	//bs.inputArr();
	bs.randomGet();
	//bs.positiveArr();
	//bs.reverseArr();
	cout << "bubbleSort: ";
	begin=clock();
	bs.bubbleSort();
	end=clock();
	//bs.printArr();
	cout << "The time is: " << (end - begin) << " ms"<< endl;

	
	bs.randomGet();
	//bs.positiveArr();
	//bs.reverseArr();
	cout << "selectSort: ";
	begin = clock();
	bs.selectSort();
	end = clock();
	//bs.printArr();
	cout << "The time is: " << (end - begin) << " ms" << endl;

	bs.randomGet();
	//bs.positiveArr();
	//bs.reverseArr();
	cout << "insertSort: ";
	begin = clock();
	bs.insertSort();
	end = clock();
	//bs.printArr();
	cout << "The time is: " << (end - begin) << " ms" << endl;

	bs.randomGet();
	//bs.positiveArr();
	//bs.reverseArr();
	cout << "quickSort: ";
	begin = clock();
	bs.quickSort(0,NUM-1);
	end = clock();
	//bs.printArr();
	cout << "The time is: " << (end - begin) << " ms" << endl;

	bs.randomGet();
	//bs.positiveArr();
	//bs.reverseArr();
	cout << "quickSort2: ";
	begin = clock();
	bs.quickSort2(0,NUM-1);
	end = clock();
	//bs.printArr();
	cout << "The time is: " << (end - begin) << " ms" << endl;

	bs.randomGet();
	//bs.positiveArr();
	//bs.reverseArr();
	cout << "heapSort: ";
	begin = clock();
	bs.heapSort();
	end = clock();
	//bs.printArr();
	cout << "The time is: " << (end - begin) << " ms" << endl;
	*/

	
	LSort ls;

	ls.inputArr();
	/*
	ls.countSort();

	ls.printArr();
	*/
	
	ls.cardinalNumSort();

	ls.printQueue();
	
	return 0;
}

