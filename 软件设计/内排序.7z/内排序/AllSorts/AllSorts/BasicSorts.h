#include <iostream>
#include <cstdlib>
#include <ctime>

#define NUM 100000

using namespace std;

template<class T>
class BSorts{
private:
	T A[NUM];
	T B[NUM];

public:
	void randomGet();

	void positiveArr();

	void reverseArr();

	void inputArr();

	void regainArr();

	void printArr();

	void bubbleSort();

	void selectSort();

	void insertSort();

	int findPivot(int i, int j);

	int Partition(int i, int j, T pivot);

	void quickSort(int i,int j);

	void quickSort2(int left, int right);

	void pushDown(int first, int last);

	void heapSort();

};

template<class T>
void BSorts<T>::positiveArr(){
	for (int i = 0; i < NUM; i++){
			A[i] = i;

	}
}

template<class T>
void BSorts<T>::reverseArr(){
	for (int i = 0; i < NUM; i++){
		A[i] = (NUM-1) - i;
	}
}

template<class T>
void BSorts<T>::randomGet(){
	time_t t = 0;
	srand(t);
	for (int i = 0; i < NUM; i++){
		A[i] = rand() % 10000;
	}
}

template<class T>
void BSorts<T>::inputArr(){
	T inp;
	for (int i = 0; i < NUM; i++){
		cin >> inp;
		A[i] = B[i] = inp;
	}
}

template<class T>
void BSorts<T>::regainArr(){
	for (int i = 0; i < NUM; i++){
		A[i] = B[i];
	}
}

template<class T>
void BSorts<T>::printArr(){
	for (int i = 0; i < NUM; i++){
		cout << A[i] << ' ';
	}
}

template<class T>
void SwapT(T &p, T &q){
	T tmp;
	tmp = p;
	p = q;
	q = tmp;
}

template<class T>
void BSorts<T>::bubbleSort(){
	for (int i = 0; i < NUM-1; i++){
		for (int j = NUM-1; j>i; j--){
			if (A[j] < A[j - 1]){
				SwapT(A[j], A[j - 1]);
			}
		}
	}
}

template<class T>
void BSorts<T>::selectSort(){
	T min;
	int minIdx;
	for (int i = 0; i < NUM-1; i++){
		minIdx = i;
		min = A[i];
		for (int j = i + 1; j < NUM; j++){
			if (A[j] < min){
				min = A[j];
				minIdx = j;
			}
		}
		SwapT(A[i], A[minIdx]);
	}
}

template<class T>
void BSorts<T>::insertSort(){
	int j;
	for (int i = 1; i < NUM; i++){
		j = i;
		while ((A[j] < A[j - 1]) && j){
			SwapT(A[j], A[j - 1]);
			j--;
		}
	}
}

template<class T>
int BSorts<T>::findPivot(int i, int j){
	T firstkey = A[i];
	for (int k = i + 1; k <= j; k++){
		if (A[k]>firstkey)
			return k;
		else if (A[k] < firstkey)
			return i;
	}
	return -1;
}

template<class T>
int BSorts<T>::Partition(int i, int j, T pivot){
	int l, r;
	do{
		for (l = i; A[l] < pivot; l++);
		for (r = j; A[r] >= pivot; r--);
		if (l < r){
			SwapT(A[l], A[r]);
		}
	} while (l <= r);
	return l;
}

template<class T>
void BSorts<T>::quickSort(int i,int j){
	T pivot;
	int k; //���ڵ���pivot����ʼ�±�
	int pivotIdx; //pivot��A���±�
	pivotIdx = findPivot(i, j);
	if (-1 != pivotIdx){
		pivot = A[pivotIdx];
		k = Partition(i, j, pivot);
		quickSort(i, k - 1);
		quickSort(k, j);
	}
}

template<class T>
void BSorts<T>::quickSort2(int left, int right){
	if (left >= right){
		return;
	}
	int i = left;
	int j = right;
	int key = A[left];
	while (i < j){
		while (i < j && key <= A[j]){
			j--;
		}
		A[i] = A[j];
		while (i < j && key >= A[i]){
			i++;
		}
		A[j] = A[i];
	}
	A[i] = key;
	quickSort2(left, i - 1);
	quickSort2(i + 1, right);
}

template<class T>
void BSorts<T>::heapSort(){
	for (int i = (NUM-2) / 2; i >= 0; i--){
		pushDown(i, NUM-1);
	}
	
	for (int i = (NUM-1); i >= 1; i--){
		SwapT(A[0], A[i]);
		pushDown(0, i - 1);
	}
	
}

template<class T>
void BSorts<T>::pushDown(int first, int last){
	int r = first;
	while (r < (last+1) / 2){
		if ((r == (last-1) / 2) && (last % 2 == 1)){
			if (A[r] > A[2 * r + 1]){
				SwapT(A[r], A[2 * r + 1]);
			}
			r = last;
		}
		else if ((A[r] > A[2 * r + 1]) && (A[2 * r + 1] <= A[2 * r + 2])){
			SwapT(A[r], A[2 * r + 1]);
			r = 2 * r + 1;
		}
		else if ((A[r] > A[2 * r + 2]) && (A[2 * r + 2] < A[2 * r + 1])){
			SwapT(A[r], A[2 * r + 2]);
			r = 2 * r + 2;
		}
		else{
			r = last;
		}
	}
}



