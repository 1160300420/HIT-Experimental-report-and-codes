#include "RBT.h"

RBT::RBT(){
	root = NULL;
}

Nodep RBT::getRoot(){
	return root;
}

Nodep getParent(Nodep p){
	return p != NULL ? p->parent : NULL;
}

void setParent(Nodep p, Nodep parent){
	if (p){
		p->parent = parent;
	}
}

bool getColor(Nodep p){
	return p != NULL ? p->color : 0;
}

bool isRed(Nodep p){
	return (p != NULL) && (p->color == 1) ? true : false;
}

bool isBlack(Nodep p){
	return !isRed(p);
}

void setRed(Nodep p){
	if (p){
		p->color = 1;
	}
}

void setBlack(Nodep p){
	if (p){
		p->color = 0;
	}
}

void setColor(Nodep p, bool color){
	if (p){
		p->color = color;
	}
}

void RBT::leftRotate(Nodep p){
	Nodep q;
	q = p->right;
	p->right = q->left;

	if (q->left){
		q->left->parent = p;
	}
	q->parent = p->parent;

	if (NULL == p->parent){
		root = q;
	}
	else{
		if (p == p->parent->left){
			p->parent->left = q;
		}
		else{
			p->parent->right = q;
		}
	}

	q->left = p;
	p->parent = q;
}

void RBT::rightRotate(Nodep p){
	Nodep q;
	q = p->left;
	p->left = q->right;

	if (q->right){
		q->right->parent = p;
	}
	q->parent = p->parent;

	if (NULL == p->parent){
		root = q;
	}
	else{
		if (p == p->parent->right){
			p->parent->right = q;
		}
		else{
			p->parent->left = q;
		}
	}
	q->right = p;
	p->parent = q;
}

void RBT::insertNode(Nodep p){
	Nodep tmp = NULL;
	Nodep x = root;

	while (x){    //find the position
		tmp = x;
		if (p->val < x->val){
			x = x->left;
		}
		else{
			x = x->right;
		}
	}
	p->parent = tmp;

	if (tmp){
		if (p->val < tmp->val){
			tmp->left = p;
		}
		else
		{
			tmp->right = p;
		}
	}
	else{
		root = p;
	}

	insertFixUp(p);

}

void RBT::insertFixUp(Nodep p){
	Nodep parent, grandp,uncle,tmp;

	while ((parent = getParent(p)) && isRed(parent)){
		grandp = getParent(parent);

		if (parent == grandp->left){
			uncle = grandp->right;

			if (uncle && isRed(uncle)){
				setBlack(parent);
				setBlack(uncle);
				setRed(grandp);
				p = grandp;
				continue;
			}

			if (p == parent->right){
				leftRotate(parent);
				tmp = parent;
				parent = p;
				p = tmp;
			}

			setBlack(parent);
			setRed(grandp);
			rightRotate(grandp);
		}
		else
		{
			uncle = grandp->left;

			if (uncle && isRed(uncle)){
				setBlack(parent);
				setBlack(uncle);
				setRed(grandp);
				p = grandp;
				continue;
			}

			if (p == parent->left){
				rightRotate(parent);
				tmp = parent;
				parent = p;
				p = tmp;
			}

			setBlack(parent);
			setRed(grandp);
			leftRotate(grandp);
		}
	}

	setBlack(root);
}

void RBT::removeNode(Nodep p){
	Nodep child, parent,replace;
	bool color;

	if (p->left && p->right){
		replace = p;
		replace = replace->right;
		while (replace->left){
			replace = replace->left;
		}

		if (getParent(p)){
			if (p == getParent(p->left)){
				getParent(p)->left = replace;
			}
			else
			{
				getParent(p)->right = replace;
			}
		}
		else
		{
			root = replace;
		}

		child = replace->right;
		parent = getParent(replace);
		color = getColor(replace);

		if (parent == p){
			parent = replace;
		}
		else{
			if (child){
				setParent(child, parent);
			}
			parent->left = child;
			replace->right = p->right;
			setParent(p->right, replace);
		}

		replace->parent = p->parent;
		replace->color = p->color;
		replace->left = p->left;
		p->left->parent = replace;

		if (color == 0){
			removeFixUp(child, parent);
		}
		p = NULL;
		return;
	}
	else if (!p->left && !p->right){
		delete(p);
	}
	else if(p->left && !p->right){
		if (getParent(p)->left == p){
			getParent(p)->left = p->left;
			delete(p);
		}
		else{
			getParent(p)->right = p->left;
			delete(p);
		}
	}
	else if(!p->left && p->right){
		if (getParent(p)->left == p){
			getParent(p)->left = p->right;
			delete(p);
		}
		else{
			getParent(p)->right = p->right;
			delete(p);
		}
	}
}

void RBT::removeFixUp(Nodep &p,Nodep &parent){
	Nodep other;

	while ((!p || isBlack(p)) && p != root){
		if (parent->left == p){
			other = parent->right;
			if (isRed(other)){
				setBlack(other);
				setRed(parent);
				leftRotate(parent);
				other = parent->right;
			}

			if ((!other->left || isBlack(other->left)) && ((!other->right) || isBlack(other->right))){
				setRed(other);
				p = parent;
				parent = getParent(p);
			}
			else
			{
				if (!other->right || isBlack(other->right)){
					setBlack(other->left);
					setRed(other);
					rightRotate(other);
					other = parent->right;
				}

				setColor(other, getColor(parent));
				setBlack(parent);
				setBlack(other->right);
				leftRotate(parent);
				p = root;
				break;
			}
		}
		else{
			other = parent->left;

			if (isRed(other)){
				setBlack(other);
				setRed(parent);
				rightRotate(parent);
				other = parent->left;
			}

			if ((!other->left || isBlack(other->left)) && ((!other->right) || isBlack(other->right))){
				setRed(other);
				p = parent;
				parent = getParent(p);
			}
			else{
				if (!other->left || isBlack(other->left)){
					setBlack(other->right);
					setRed(other);
					leftRotate(other);
					other - parent->left;
				}

				setColor(other, getColor(parent));
				setBlack(parent);
				setBlack(other->left);
				rightRotate(parent);
				p = root;
				break;
			}
		}
	}

	if (!p){
		setBlack(p);
	}
}

void RBT::buildRBT(){
	for (int i = 0; i < 9; i++){
		Nodep p=new Node;
		cin >> p->val;
		p->left = p->right = p->parent = NULL;
		p->color = 1;
		insertNode(p);
	}
}

void RBT::printRBT(Nodep t,int value,int dir){
	if (t){
		if (0 == dir){
			cout << "root is " << t->val << endl;
		}
		else{
			cout << t->val << "(" <<(isRed(t) ? "r" : "b") <<")"<<' '<< "is" <<' '<< value << " 's " << (dir == 1 ? "right" : "left") << " child" << endl;
		}
		printRBT(t->left, t->val, -1);
		printRBT(t->right, t->val, 1);
	}
}

Nodep RBT::findNode(int value){
	Nodep p;
	p = root;
	while (p){
		if (value < p->val){
			p = p->left;
		}
		else if(value>p->val){
			p = p->right;
		}
		else{
			return p;
		}
	}
}