#include <iostream>

typedef struct Node{
	bool color;
	int val;
	Node *left;
	Node *right;
	Node *parent;
}*Nodep;
using namespace std;

class RBT{
private:
	Nodep root;
public:
	RBT();

	void leftRotate(Nodep p);

	void rightRotate(Nodep p);

	void insertNode(Nodep p);

	void insertFixUp(Nodep p);

	void removeNode(Nodep p);

	void removeFixUp(Nodep &p,Nodep &parent);

	void buildRBT();

	void printRBT(Nodep t, int value, int dir);

	Nodep findNode(int value);

	

	Nodep getRoot();
};