#include <iostream>
#include <queue>

typedef struct Node{
	int val;
	Node *left;
	Node *right;
	int bf;
	int h;
}*Nodep;

using namespace std;

class AVLTree{
private:
	Nodep root;
public:
	Nodep singleRotateWithLeft(Nodep pNode);

	Nodep singleRotateWithRight(Nodep pNode);

	Nodep doubleRotateWithLeft(Nodep pNode);

	Nodep doubleRotateWithRight(Nodep pNode);

	Nodep getRoot();

	int Height(Nodep pNode);

	void buildAVL();

	Nodep insertNode(int value,Nodep &pNode);

	void deleteNode(int value);

	void printTree(Nodep pNode);

	void printByFloor();

	void findVal(int value,Nodep pNode);

	void findNode();

	void addBf();

	void leftB_div(Nodep &p, int &shorter);

	void rightB_div(Nodep &p, int &shorter);

	void deleteNode(Nodep q,Nodep &r,int &shorter);

	void deleteAVL(Nodep &p, int x, int &shorter);

	void deleteFinal();


};