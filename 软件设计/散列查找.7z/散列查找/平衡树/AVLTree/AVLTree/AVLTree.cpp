// AVLTree.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "AVL.h"

int main()
{
	cout << "Please input 0--5 to choose the menu(do while the input comes to '-1') " << endl;
	cout << "0 for Build the AVL Tree(input the num of the Nodes and the value of them)" << endl;
	cout << "1 for insert the Nodes(do while the input comes to '-1')" << endl;
	cout << "2 for find the Nodes(do while the input comes to '-1')" << endl;
	cout << "3 for delete the Nodes(do while the input comes to '-1')" << endl;
	cout << "4 for print the val , floor and bf of the Nodes" << endl;
	cout << "5 for print the Nodes by floor" << endl;

	AVLTree at;
	int menu;
	cin >> menu;
	while (-1 != menu){
		switch (menu)
		{
		case 0: 
			at.buildAVL();
			break;
		case 1:
			cout << "refer to buildAVL" << endl;
			break;
		case 2:
			cout << "Please input the Node you want to find: ";
			at.findNode();
			break;
		case 3:
			cout << "Please input the Node you want to delete: ";
			at.deleteFinal();
			break;
		case 4:
			at.printTree(at.getRoot());
			break;
		case 5:
			at.printByFloor();
			break;
		default:
			cout << "error input" << endl;
			break;
		}
		cin >> menu;
	}

	return 0;
}

