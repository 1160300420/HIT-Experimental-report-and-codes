#include "AVL.h"

Nodep AVLTree::getRoot(){
	return root;
}

int AVLTree::Height(Nodep pNode){
	if (NULL == pNode)
		return -1;
	return pNode->h;
}

int max(int a, int b){
	return (a > b) ? a : b;
}

void AVLTree::buildAVL(){
	int n,value;
	root = NULL;
	cin >> n;
	for (int i = 0; i < n; i++){
		cin >> value;
		insertNode(value, root);
	}
	addBf();
}

Nodep AVLTree::singleRotateWithRight(Nodep pNode){  //llr
	Nodep p;
	p = pNode->left;
	pNode->left = p->right;
	p->right = pNode;

	pNode->h = max(Height(pNode->left), Height(pNode->right)) + 1;
	p->h = max(Height(p->left), pNode->h) + 1;
	//p->left->h = max(Height(p->left->left), Height(p->left->right))+1;

	return p;

}

Nodep AVLTree::singleRotateWithLeft(Nodep pNode){
	Nodep p;
	p = pNode->right;
	pNode->right = p->left;
	p->left = pNode;

	pNode->h = max(Height(pNode->left), Height(pNode->right)) + 1;
	p->h = max(Height(p->left), pNode->h) + 1;
	//p->right->h = max(Height(p->right->left), Height(p->right->right))+1;

	return p;
}

Nodep AVLTree::doubleRotateWithRight(Nodep pNode){
	pNode->left = singleRotateWithLeft(pNode->left);

	return singleRotateWithRight(pNode);
}

Nodep AVLTree::doubleRotateWithLeft(Nodep pNode){
	pNode->right = singleRotateWithRight(pNode->right);

	return singleRotateWithLeft(pNode);
}

Nodep AVLTree::insertNode(int value,Nodep &pNode){
	
	if (NULL == pNode){
		pNode = new Node;
		pNode->val = value;
		pNode->h = 0;
		pNode->left = pNode->right = NULL;
	}
	else if (value < pNode->val){
		pNode->left = insertNode(value,pNode->left);
		if (Height(pNode->left) - Height(pNode->right) == 2){
			if (value < pNode->left->val){
				pNode = singleRotateWithRight(pNode);
			}
			else{
				pNode = doubleRotateWithRight(pNode);
			}
		}
	}
	else if (value>pNode->val){
		pNode->right = insertNode(value, pNode->right);
		if (Height(pNode->right) - Height(pNode->left) == 2){
			if (value > pNode->right->val){
				pNode = singleRotateWithLeft(pNode);
			}
			else{
				pNode = doubleRotateWithLeft(pNode);
			}
		}
	}

	pNode->h = max(Height(pNode->left), Height(pNode->right))+1;

	//cout << pNode->h << 'a' << endl;

	return pNode;
}

void AVLTree::printTree(Nodep pNode){
	if (NULL == pNode){
		return;
	}
	
	printTree(pNode->left);
	cout << pNode->val << ' ' << pNode->h <<' '<<pNode->bf<< endl;
	printTree(pNode->right);
}

void AVLTree::printByFloor(){
	queue<Nodep> q;
	Nodep p;
	q.push(root);
	while (!q.empty()){
		p = q.front();
		q.pop();
		cout << p->val << ' ';

		if (p){
			if (p->left){
				q.push(p->left);
			}
			if (p->right){
				q.push(p->right);
			}
		}	
	}
	cout << endl;
}

void AVLTree::findVal(int value, Nodep pNode){
	if (NULL == pNode){
		cout << "Not found" << endl;
		return;
	}
	if (value == pNode->val){
		cout << "Found" << ' ' << pNode->val << endl;
	}
	else if (value < pNode->val){
		findVal(value, pNode->left);
	}
	else if (value>pNode->val){
		findVal(value, pNode->right);
	}
}

void AVLTree::findNode(){
	int value;
	cin >> value;
	while (-1 != value){
		findVal(value, root);
		cin >> value;
	}
}

void AVLTree::addBf(){
	queue<Nodep> qm;
	Nodep p;
	qm.push(root);
	while (!qm.empty()){
		p = qm.front();
		qm.pop();
		if (!p->left && !p->right){
			p->bf = 0;
		}
		else if (!p->left&&p->right){
			p->bf = -1;
		}
		else if (p->left&&!p->right){
			p->bf = 1;
		}
		else{
			p->bf = (p->left->h) - (p->right->h);
		}
		
		if (p){
			if (p->left){
				qm.push(p->left);
			}
			if (p->right){
				qm.push(p->right);
			}
		}
	}
}

void L_rotate(Nodep &p){
	Nodep q;
	q = p->right;
	p->right = q->left;
	q->left = p;
	p = q;
}

void R_rotate(Nodep &p){
	Nodep q;
	q = p->left;
	p->left = q->right;
	q->right = p;
	p = q;
}

void AVLTree::leftB_div(Nodep &p,int &shorter){
	Nodep p1, p2;
	if (1 == p->bf){
		p->bf = 0;
		shorter = 1;
	}
	else if (0 == p->bf){
		p->bf = -1;
		shorter = 0;
	}
	else{
		p1 = p->right;
		if (0 == p1->bf){
			L_rotate(p);
			p1->bf = 1;
			p->bf = -1;
			shorter = 0;
		}
		else if (-1 == p1->bf){
			L_rotate(p);
			p1->bf = p->bf = 0;
			shorter = 1;
		}
		else
		{
			p2 = p1->left;
			p1->left = p2->right;
			p2->right = p1;
			p->right = p2->left;
			p2->left = p;
			if (0 == p2->bf){
				p->bf = 0;
				p1->bf = 0;
			}
			else if (-1 == p2->bf){
				p->bf = 1;
				p1->bf = 0;
			}
			else{
				p->bf = 0;
				p1->bf = -1;
			}

			p2->bf = 0;
			p = p2;
			shorter = 1;
		}
	}
}

void AVLTree::rightB_div(Nodep &p, int &shorter){
	Nodep p1, p2;
	if (-1 == p->bf){
		p->bf = 0;
		shorter = 1;
	}
	else if (0==p->bf)
	{
		p->bf = 1;
		shorter = 0;
	}
	else{
		p1 = p->left;
		if (0 == p1->bf){
			R_rotate(p);
			p1->bf = -1;
			p->bf = 1;
			shorter = 0;
		}
		else if (1 == p1->bf){
			R_rotate(p);
			p1->bf = p->bf = 0;
			shorter = 1;
		}
		else{
			p2 = p1->right;
			p1->right = p2->right;
			p2->left = p1;
			p2->right = p;
			if (0 == p2->bf){
				p->bf = 0;
				p1->bf = 0;
			}
			else if (1 == p2->bf){
				p->bf = -1;
				p1->bf = 0;
			}
			else{
				p->bf = 0;
				p1->bf = 1;
			}

			p2->bf = 0;
			p = p2;
			shorter = 1;
		}
	}
}

void AVLTree::deleteNode(Nodep q,Nodep &r,int &shorter){
	if (NULL == r->right){
		q->val = r->val;
		q = r;
		r = r->left;
		delete(q);
		shorter = 1;
	}
	else{
		deleteNode(q, r->right, shorter);
		if (1 == shorter){
			rightB_div(r, shorter);
		}
	}
}

void AVLTree::deleteAVL(Nodep &p, int x, int &shorter){
	Nodep q;
	if (NULL == p){
		cout << "No such Node" << endl;
		return;
	}
	else if (x < p->val){
		deleteAVL(p->left, x, shorter);
		if (1 == shorter){
			leftB_div(p, shorter);
		}
	}
	else if (x>p->val){
		deleteAVL(p->right, x, shorter);
		if (1 == shorter){
			rightB_div(p, shorter);
		}
	}
	else{
		q = p;
		if (NULL == p->right){
			p = p->left;
			delete(p);
			shorter = 1;
		}
		else if (NULL == p->left){
			p = p->right;
			delete(q);
			shorter = 1;
		}
		else{
			deleteNode(q, q->left, shorter);
			if (1 == shorter){
				leftB_div(p, shorter);
			}
			p = q;
		}
	}
}

void AVLTree::deleteFinal(){
	int shorter = 0;
	int x;
	cin >> x;
	while (-1 != x){
		deleteAVL(root, x, shorter);
		cin >> x;
	}
}
