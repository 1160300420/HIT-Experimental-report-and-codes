#include <iostream>
#include <string>

#define NUM 40

using namespace std;

struct records{
	string str;
	int cnt;
};

typedef struct Unit{
	records data;
	Unit *next;
} *Unitp;

typedef struct Node{
	Unitp unit;
	Node *left;
	Node *right;
}*Nodep;

class HashList
{
private:
	Unitp HASH[NUM];

	Nodep root;

	int cnt;
public:
	HashList();

	Nodep getRoot();

	Unitp searchUnit(string str);

	void insertUnit(string str);

	void deleteUnit(string str);

	void buildHashList();

	void build(Nodep &rt,Unitp r);

	void buildBST();

	void preMap(Nodep rt);
};