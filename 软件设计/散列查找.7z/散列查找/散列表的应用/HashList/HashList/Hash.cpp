#include "Hash.h"

HashList::HashList(){
	for (int i = 0; i < NUM; i++){
		HASH[i] = NULL;
	}

	root = NULL;

	cnt = 0;
}

Nodep HashList::getRoot(){
	return root;
}

int h(int k){
	return k%NUM;
}

int string2value(string str){
	int value = 0;
	for (int i = 0; i < str.length(); i++){
		value += (int)str[i];
	}
	return value;
}

Unitp HashList::searchUnit(string str){
	Unitp p;
	int value;

	value = string2value(str);
	p = HASH[h(value)];
	while (p)
	{
		if (p->data.str==str)
		{
			return p;
		} 
		else
		{
			p = p->next;
		}
	}
	return p;  //return NULL
}

void HashList::insertUnit(string str){
	int bucket;
	Unitp q, p;
	p = searchUnit(str);
	if (!p){
		bucket = h(string2value(str));
		q = HASH[bucket];
		HASH[bucket] = new Unit;
		HASH[bucket]->data.str = str;
		HASH[bucket]->data.cnt = 1;
		HASH[bucket]->next = q;
	}
	else{
		p->data.cnt++;
	}
}

void HashList::deleteUnit(string str){
	int bucket;
	bucket = h(string2value(str));
	Unitp q, p;
	if (HASH[bucket]){
		if (HASH[bucket]->data.str == str){
			q = HASH[bucket];
			HASH[bucket] = HASH[bucket]->next;
			delete(q);
		}
		else{
			q = HASH[bucket];
			while (q->next){
				if (q->next->data.str == str){
					p = q->next;
					q->next = p->next;
					delete(p);
				}
				else{
					q = q->next;
				}
			}
		}
	}
}

void HashList::buildHashList(){
	string str;
	for (int i = 0; i < NUM; i++){
		cin >> str;
		insertUnit(str);
	}
	
}

void HashList::build(Nodep &rt,Unitp r){
	if (!rt){
		rt = new Node;
		rt->unit = r;
		rt->left = NULL;
		rt->right = NULL;
	}else if (r->data.cnt > rt->unit->data.cnt){
		build(rt->left, r);
	}
	else
	{
		build(rt->right, r);
	}
}

void HashList::buildBST(){
	Unitp p;
	
	for (int i = 0; i < NUM; i++){
		p = HASH[i];	
		while (p){
			build(root, p);
			p = p->next;
		}
	}
	
}//���������

void HashList::preMap(Nodep rt){
	if (cnt > 9) return;
	cnt++;
	if (rt->left)
		preMap(rt->left);

	cout << rt->unit->data.str << ' ' << rt->unit->data.cnt << endl;

	if (rt->right)
		preMap(rt->right);
}
