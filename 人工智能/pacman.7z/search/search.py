# -*- coding: utf-8 -*- 
# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]
	
def graphSearch(problem, fringe):
	pgss=problem.getStartState()     #获取problem的初始状态
	print "Start:", pgss       #打印problem的初始状态
	print "Is the start a goal?", problem.isGoalState(pgss)    #判断初始状态是目标状态吗
	print "Start's successors:", problem.getSuccessors(pgss)   #打印初始状态的子状态（与这一状态连接的可达状态）
	
	visited = []       #记录这个状态是否访问过，访问过的状态都被添加到visited列表里
	fringe.push([(pgss, "Stop" , 0)])    #向数据及结构（依fringe定义的数据结构而定）压入初始状态三元组构成的访问路径，三元组元素分别为状态，方向，访问步数
	
	while not fringe.isEmpty():        #数据结构不为空一直循环
		path = fringe.pop() 		  #将数据弹出一个（栈顶，队首...）路径
		s = path[len(path)-1]         #取得路径末的三元组（及访问路径中最后一个状态所在的三元组）
		s = s[0]                #取得本路径的最后状态
		if problem.isGoalState(s):       #如果取得的这最后一个状态就是我们的目标状态，则搜索结束
			return [x[1] for x in path][1:]      #返回路径中所有的方向（除去初始状态的方向）
			
		if s not in visited:          #如果这个状态还没被访问过
			visited.append(s)         #访问这个状态，并将这个状态添加到访问记录列表visited[]中
			
			for successor in problem.getSuccessors(s):    #遍历现状态的子状态
				if successor[0] not in visited:			#子状态没有被访问过
					successorPath = path[:]            #创建新的子状态路径（复制当前状态的路径），此处的[:]为了防止python的引用处理，这样可以真正创建新的路径
					successorPath.append(successor)    #在原状态路径后面添加上当前访问的子状态，得到新的状态路径
					fringe.push(successorPath)       #将新的状态路径压入数据结构中
	return []  

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    fringe = util.Stack()    #fringe数据结构为栈，进行dfs
    return graphSearch(problem, fringe)

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    fringe = util.Queue()    #fringe数据结构为队列，进行bfs
    return graphSearch(problem, fringe)

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    cost = lambda aPath: problem.getCostOfActions([x[1] for x in aPath])    #计算出每条路径的总代价，通过总代价作为优先级进行搜索
    fringe = util.PriorityQueueWithFunction(cost)        #fringe数据结构为优先队列
    return graphSearch(problem, fringe)

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    cost = lambda aPath: problem.getCostOfActions([x[1] for x in aPath]) + heuristic(aPath[len(aPath)-1][0], problem)
    fringe = util.PriorityQueueWithFunction(cost)  #A*是对代价一致搜索算法的改进，加入了一个估计代价h
    return graphSearch(problem, fringe)


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
